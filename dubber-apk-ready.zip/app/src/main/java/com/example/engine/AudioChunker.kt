package com.example.engine

import com.example.model.TranscriptSegment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sqrt

/**
 * Splits extracted audio into timestamped speech chunks using Voice Activity Detection (VAD)
 * to prevent memory overload and ensure natural sentence boundary alignment.
 */
class AudioChunker {

    suspend fun segmentAudioWav(
        wavFile: File,
        totalDurationMs: Long,
        onProgress: (Float, Int) -> Unit
    ): List<TranscriptSegment> = withContext(Dispatchers.IO) {
        val segments = mutableListOf<TranscriptSegment>()
        val raf = RandomAccessFile(wavFile, "r")

        try {
            // Skip 44-byte WAV header
            val fileLength = raf.length()
            if (fileLength <= 44) {
                // If audio is practically empty, return a single fallback segment
                return@withContext listOf(
                    TranscriptSegment(
                        id = 1,
                        startMs = 0L,
                        endMs = totalDurationMs.coerceAtLeast(1000L),
                        sourceText = "",
                        translatedHindiText = ""
                    )
                )
            }

            raf.seek(44)
            val pcmDataLength = fileLength - 44
            val sampleRate = 16000
            val bytesPerSample = 2 // 16-bit
            val totalSamples = pcmDataLength / bytesPerSample
            val calculatedDurationMs = (totalSamples * 1000L) / sampleRate

            val actualDurationMs = if (totalDurationMs > 0) totalDurationMs else calculatedDurationMs

            // 100ms frame analysis window = 1600 samples = 3200 bytes
            val frameMs = 100
            val samplesPerFrame = sampleRate * frameMs / 1000
            val bytesPerFrame = samplesPerFrame * bytesPerSample

            val frameCount = (totalSamples / samplesPerFrame).toInt()
            val frameEnergies = FloatArray(frameCount)

            val frameBuffer = ByteArray(bytesPerFrame)
            val shortBuffer = ByteBuffer.allocate(bytesPerFrame).order(ByteOrder.LITTLE_ENDIAN)

            var frameIdx = 0
            while (frameIdx < frameCount) {
                val read = raf.read(frameBuffer)
                if (read < bytesPerFrame) break

                shortBuffer.clear()
                shortBuffer.put(frameBuffer, 0, read)
                shortBuffer.flip()

                var sumSquares = 0.0
                val shortsCount = read / 2
                for (s in 0 until shortsCount) {
                    val sample = shortBuffer.short.toDouble()
                    sumSquares += sample * sample
                }
                val rms = sqrt(sumSquares / shortsCount).toFloat()
                frameEnergies[frameIdx] = rms

                if (frameIdx % 50 == 0 && frameCount > 0) {
                    onProgress((frameIdx.toFloat() / frameCount.toFloat()) * 0.5f, segments.size)
                }
                frameIdx++
            }

            // Adaptive silence threshold based on median/ambient energy
            val sortedEnergies = frameEnergies.clone().apply { sort() }
            val medianEnergy = if (sortedEnergies.isNotEmpty()) sortedEnergies[sortedEnergies.size / 4] else 200f
            val silenceThreshold = (medianEnergy * 1.8f).coerceIn(350f, 1500f)

            // State machine to identify speech spans and split into 2s - 7s segments
            var inSpeech = false
            var speechStartMs = 0L
            var silenceFramesCount = 0
            val maxSilenceFrames = 4 // ~400ms pause indicates sentence break
            val minSegmentDurationMs = 1500L // 1.5 seconds minimum
            val maxSegmentDurationMs = 7000L // 7 seconds maximum to prevent long run-ons

            var segmentIdCounter = 1

            for (i in 0 until frameCount) {
                val currentMs = i.toLong() * frameMs
                val energy = frameEnergies[i]
                val isSpeechFrame = energy > silenceThreshold

                if (isSpeechFrame) {
                    silenceFramesCount = 0
                    if (!inSpeech) {
                        inSpeech = true
                        speechStartMs = currentMs
                    } else {
                        // If segment exceeds maximum duration, split at this frame
                        if (currentMs - speechStartMs >= maxSegmentDurationMs) {
                            segments.add(
                                TranscriptSegment(
                                    id = segmentIdCounter++,
                                    startMs = speechStartMs,
                                    endMs = currentMs,
                                    sourceText = "",
                                    translatedHindiText = ""
                                )
                            )
                            speechStartMs = currentMs
                        }
                    }
                } else {
                    if (inSpeech) {
                        silenceFramesCount++
                        if (silenceFramesCount >= maxSilenceFrames) {
                            val duration = currentMs - speechStartMs
                            if (duration >= minSegmentDurationMs) {
                                segments.add(
                                    TranscriptSegment(
                                        id = segmentIdCounter++,
                                        startMs = speechStartMs,
                                        endMs = currentMs,
                                        sourceText = "",
                                        translatedHindiText = ""
                                    )
                                )
                            }
                            inSpeech = false
                            silenceFramesCount = 0
                        }
                    }
                }
            }

            // If audio finished while in speech, commit final segment
            if (inSpeech) {
                val endMs = (frameCount.toLong() * frameMs).coerceAtMost(actualDurationMs)
                if (endMs - speechStartMs >= 800L) {
                    segments.add(
                        TranscriptSegment(
                            id = segmentIdCounter++,
                            startMs = speechStartMs,
                            endMs = endMs,
                            sourceText = "",
                            translatedHindiText = ""
                        )
                    )
                }
            }

            // If no speech detected (e.g. quiet video or instrumental), create uniform 4-second blocks
            if (segments.isEmpty()) {
                val blockDuration = 4000L
                var cursor = 0L
                while (cursor < actualDurationMs) {
                    val next = (cursor + blockDuration).coerceAtMost(actualDurationMs)
                    segments.add(
                        TranscriptSegment(
                            id = segmentIdCounter++,
                            startMs = cursor,
                            endMs = next,
                            sourceText = "",
                            translatedHindiText = ""
                        )
                    )
                    cursor = next
                }
            }

            onProgress(1.0f, segments.size)
            segments

        } finally {
            try {
                raf.close()
            } catch (_: Exception) {}
        }
    }
}
