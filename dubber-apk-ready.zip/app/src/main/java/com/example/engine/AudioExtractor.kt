package com.example.engine

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Extracts the audio track from any video container (MP4, MKV, AVI, WebM)
 * and decodes it to standard 16,000 Hz, 16-bit Mono PCM WAV format.
 */
class AudioExtractor(private val context: Context) {

    data class ExtractionResult(
        val wavFile: File,
        val sampleRate: Int = 16000,
        val channels: Int = 1,
        val durationMs: Long,
        val waveformAmplitudes: List<Float>
    )

    suspend fun extractAudioToWav(
        videoUri: Uri,
        outputWavFile: File,
        onProgress: (Float, String) -> Unit
    ): ExtractionResult = withContext(Dispatchers.IO) {
        val pfd = context.contentResolver.openFileDescriptor(videoUri, "r")
            ?: throw IllegalStateException("Cannot open video file descriptor from URI: $videoUri")

        val extractor = MediaExtractor()
        var decoder: MediaCodec? = null

        val tempPcmFile = File(outputWavFile.parentFile, "${outputWavFile.name}.pcm")
        if (tempPcmFile.exists()) tempPcmFile.delete()
        if (outputWavFile.exists()) outputWavFile.delete()

        val pcmOutputStream = FileOutputStream(tempPcmFile)

        try {
            extractor.setDataSource(pfd.fileDescriptor)
            val numTracks = extractor.trackCount
            var audioTrackIndex = -1
            var audioFormat: MediaFormat? = null

            for (i in 0 until numTracks) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    audioFormat = format
                    break
                }
            }

            if (audioTrackIndex == -1 || audioFormat == null) {
                throw IllegalStateException("No audio track detected in selected video file")
            }

            extractor.selectTrack(audioTrackIndex)
            val mimeType = audioFormat.getString(MediaFormat.KEY_MIME)!!
            val srcSampleRate = if (audioFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                audioFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            } else 44100
            val srcChannelCount = if (audioFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                audioFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            } else 2

            val durationUs = if (audioFormat.containsKey(MediaFormat.KEY_DURATION)) {
                audioFormat.getLong(MediaFormat.KEY_DURATION)
            } else 0L
            val durationMs = if (durationUs > 0) durationUs / 1000 else 1000L

            onProgress(0.05f, "Found $mimeType track: ${srcSampleRate}Hz, $srcChannelCount ch")

            decoder = MediaCodec.createDecoderByType(mimeType)
            decoder.configure(audioFormat, null, null, 0)
            decoder.start()

            val bufferInfo = MediaCodec.BufferInfo()
            var isInputEOS = false
            var isOutputEOS = false
            val timeoutUs = 10_000L

            var totalPcmBytes = 0L
            val waveformSamples = mutableListOf<Float>()
            var sampleCounter = 0
            val sampleStep = (srcSampleRate * srcChannelCount / 10).coerceAtLeast(1) // ~10 points per sec

            // Re-sampling accumulator from source sample rate to 16kHz mono
            val targetSampleRate = 16000
            val resampleRatio = srcSampleRate.toDouble() / targetSampleRate.toDouble()

            // Temporary accumulator for PCM downsampling
            var resampleAccumulator = 0.0

            while (!isOutputEOS) {
                if (!isInputEOS) {
                    val inputBufIndex = decoder.dequeueInputBuffer(timeoutUs)
                    if (inputBufIndex >= 0) {
                        val inputBuffer = decoder.getInputBuffer(inputBufIndex)
                        if (inputBuffer != null) {
                            val sampleSize = extractor.readSampleData(inputBuffer, 0)
                            if (sampleSize < 0) {
                                decoder.queueInputBuffer(
                                    inputBufIndex, 0, 0, 0,
                                    MediaCodec.BUFFER_FLAG_END_OF_STREAM
                                )
                                isInputEOS = true
                            } else {
                                val presentationTimeUs = extractor.sampleTime
                                decoder.queueInputBuffer(
                                    inputBufIndex, 0, sampleSize, presentationTimeUs, 0
                                )
                                extractor.advance()
                            }
                        }
                    }
                }

                val outputBufIndex = decoder.dequeueOutputBuffer(bufferInfo, timeoutUs)
                if (outputBufIndex >= 0) {
                    val outputBuffer = decoder.getOutputBuffer(outputBufIndex)
                    if (outputBuffer != null && bufferInfo.size > 0) {
                        outputBuffer.position(bufferInfo.offset)
                        outputBuffer.limit(bufferInfo.offset + bufferInfo.size)

                        val shortBuffer = outputBuffer.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                        val numShorts = bufferInfo.size / 2
                        val shorts = ShortArray(numShorts)
                        shortBuffer.get(shorts)

                        // Convert to Mono 16kHz
                        val outShorts = ArrayList<Short>()
                        val frameSize = srcChannelCount

                        var frameIdx = 0
                        val totalFrames = numShorts / frameSize

                        while (frameIdx < totalFrames) {
                            var monoSample = 0
                            for (c in 0 until frameSize) {
                                val sIndex = frameIdx * frameSize + c
                                if (sIndex < shorts.size) {
                                    monoSample += shorts[sIndex]
                                }
                            }
                            monoSample /= frameSize

                            // Simple nearest-neighbor resample to 16kHz
                            while (resampleAccumulator < 1.0 && frameIdx < totalFrames) {
                                outShorts.add(monoSample.toShort())
                                resampleAccumulator += resampleRatio
                            }
                            resampleAccumulator -= 1.0
                            frameIdx++

                            // Waveform sampling
                            sampleCounter++
                            if (sampleCounter % sampleStep == 0) {
                                val norm = kotlin.math.abs(monoSample) / 32768f
                                waveformSamples.add(norm.coerceIn(0f, 1f))
                            }
                        }

                        // Write to PCM file (16-bit Little Endian)
                        val outBytes = ByteArray(outShorts.size * 2)
                        val bb = ByteBuffer.wrap(outBytes).order(ByteOrder.LITTLE_ENDIAN)
                        for (s in outShorts) {
                            bb.putShort(s)
                        }
                        pcmOutputStream.write(outBytes)
                        totalPcmBytes += outBytes.size

                        val currentUs = bufferInfo.presentationTimeUs
                        if (durationUs > 0) {
                            val ratio = (currentUs.toFloat() / durationUs.toFloat()).coerceIn(0.1f, 0.95f)
                            onProgress(ratio, "Decoding audio: ${(currentUs / 1000) / 1000}s / ${durationMs / 1000}s")
                        }
                    }

                    decoder.releaseOutputBuffer(outputBufIndex, false)

                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        isOutputEOS = true
                    }
                }
            }

            pcmOutputStream.flush()
            pcmOutputStream.close()

            onProgress(0.96f, "Packaging 16kHz 16-bit Mono WAV container...")
            convertPcmToWav(tempPcmFile, outputWavFile, targetSampleRate, 1, 16)
            tempPcmFile.delete()

            onProgress(1.0f, "Audio extraction completed (${outputWavFile.length() / 1024} KB)")

            ExtractionResult(
                wavFile = outputWavFile,
                sampleRate = targetSampleRate,
                channels = 1,
                durationMs = durationMs,
                waveformAmplitudes = if (waveformSamples.isEmpty()) listOf(0.1f, 0.3f, 0.2f) else waveformSamples
            )

        } finally {
            try {
                decoder?.stop()
                decoder?.release()
            } catch (_: Exception) {}
            try {
                extractor.release()
            } catch (_: Exception) {}
            try {
                pfd.close()
            } catch (_: Exception) {}
        }
    }

    private fun convertPcmToWav(
        pcmFile: File,
        wavFile: File,
        sampleRate: Int,
        channels: Int,
        bitsPerSample: Int
    ) {
        val pcmSize = pcmFile.length()
        val totalDataLen = pcmSize + 36
        val byteRate = sampleRate * channels * bitsPerSample / 8

        val wavOut = RandomAccessFile(wavFile, "rw")
        wavOut.setLength(0)

        // Write 44-byte WAV RIFF Header
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray())
        header.putInt(totalDataLen.toInt())
        header.put("WAVE".toByteArray())
        header.put("fmt ".toByteArray())
        header.putInt(16) // Subchunk1Size for PCM
        header.putShort(1.toShort()) // AudioFormat 1 = PCM
        header.putShort(channels.toShort())
        header.putInt(sampleRate)
        header.putInt(byteRate)
        header.putShort((channels * bitsPerSample / 8).toShort()) // BlockAlign
        header.putShort(bitsPerSample.toShort())
        header.put("data".toByteArray())
        header.putInt(pcmSize.toInt())

        wavOut.write(header.array())

        // Stream PCM data
        pcmFile.inputStream().use { input ->
            val buf = ByteArray(32 * 1024)
            var read: Int
            while (input.read(buf).also { read = it } != -1) {
                wavOut.write(buf, 0, read)
            }
        }
        wavOut.close()
    }
}
