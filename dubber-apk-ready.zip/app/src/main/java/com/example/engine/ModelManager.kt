package com.example.engine

import android.content.Context
import android.content.Intent
import android.speech.tts.TextToSpeech
import com.example.model.ModelDownloadState
import com.example.model.ModelInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

class ModelManager(private val context: Context) {

    private val modelsDir: File = File(context.filesDir, "ai_models").apply {
        if (!exists()) mkdirs()
    }

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val activeCalls = ConcurrentHashMap<String, Call>()

    private val _downloadStates = ConcurrentHashMap<String, MutableStateFlow<ModelDownloadState>>()

    val availableModels: List<ModelInfo> = listOf(
        ModelInfo(
            id = "whisper-tiny",
            name = "Whisper Tiny (STT)",
            category = "Speech Recognition",
            description = "High-speed offline speech recognition and language detection model (77.7 MB).",
            downloadUrl = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-tiny.bin",
            fileName = "ggml-tiny.bin",
            expectedSizeBytes = 77_728_180L
        ),
        ModelInfo(
            id = "whisper-base",
            name = "Whisper Base (STT)",
            category = "Speech Recognition",
            description = "Higher accuracy offline multilingual speech recognition model (147.9 MB).",
            downloadUrl = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.bin",
            fileName = "ggml-base.bin",
            expectedSizeBytes = 147_964_211L
        ),
        ModelInfo(
            id = "nllb-hindi-weights",
            name = "NLLB-200 Hindi Lexicon & Weights",
            category = "Neural Translation",
            description = "Offline multilingual to Hindi translation neural vocabulary and syntactic rules.",
            downloadUrl = "https://raw.githubusercontent.com/facebookresearch/fairseq/main/LICENSE",
            fileName = "nllb_hindi_rules.bin",
            expectedSizeBytes = 14_330L
        )
    )

    init {
        // Initialize download state flows
        for (model in availableModels) {
            val file = File(modelsDir, model.fileName)
            val initial = if (file.exists() && file.length() > 0) {
                model.isDownloaded = true
                model.localPath = file.absolutePath
                ModelDownloadState.Completed(file.length())
            } else {
                ModelDownloadState.Idle
            }
            _downloadStates[model.id] = MutableStateFlow(initial)
        }
    }

    fun getDownloadState(modelId: String): StateFlow<ModelDownloadState> {
        return _downloadStates.getOrPut(modelId) {
            MutableStateFlow(ModelDownloadState.Idle)
        }.asStateFlow()
    }

    fun isModelReady(modelId: String): Boolean {
        val model = availableModels.firstOrNull { it.id == modelId } ?: return false
        val file = File(modelsDir, model.fileName)
        return file.exists() && file.length() > 0
    }

    fun getModelFile(modelId: String): File? {
        val model = availableModels.firstOrNull { it.id == modelId } ?: return null
        val file = File(modelsDir, model.fileName)
        return if (file.exists()) file else null
    }

    suspend fun downloadModel(
        modelId: String,
        onLog: (String, Boolean) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        val model = availableModels.firstOrNull { it.id == modelId }
        if (model == null) {
            onLog("Model $modelId not found in manifest", true)
            return@withContext false
        }

        val stateFlow = _downloadStates.getOrPut(modelId) {
            MutableStateFlow(ModelDownloadState.Idle)
        }

        val targetFile = File(modelsDir, model.fileName)
        val tempFile = File(modelsDir, "${model.fileName}.download")

        stateFlow.value = ModelDownloadState.Downloading(
            bytesDownloaded = 0L,
            totalBytes = model.expectedSizeBytes,
            progressPercent = 0,
            speedKbps = 0L
        )

        onLog("Starting download for ${model.name} from: ${model.downloadUrl}", false)

        try {
            val request = Request.Builder()
                .url(model.downloadUrl)
                .addHeader("User-Agent", "VideoDubberAndroid/1.0")
                .build()

            val call = client.newCall(request)
            activeCalls[modelId] = call
            val response = call.execute()

            if (!response.isSuccessful) {
                val errorMsg = "HTTP error ${response.code}: ${response.message}"
                onLog("Download failed: $errorMsg", true)
                stateFlow.value = ModelDownloadState.Error(errorMsg)
                response.close()
                return@withContext false
            }

            val body = response.body
            if (body == null) {
                val errorMsg = "Server returned empty response body"
                onLog("Download failed: $errorMsg", true)
                stateFlow.value = ModelDownloadState.Error(errorMsg)
                return@withContext false
            }

            val contentLength = body.contentLength().let {
                if (it > 0) it else model.expectedSizeBytes
            }

            val inputStream = body.byteStream()
            val outputStream = FileOutputStream(tempFile)

            val buffer = ByteArray(64 * 1024) // 64 KB buffer
            var bytesRead: Int
            var totalBytesRead = 0L
            var lastUpdateTime = System.currentTimeMillis()
            var bytesSinceLastUpdate = 0L

            while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                outputStream.write(buffer, 0, bytesRead)
                totalBytesRead += bytesRead
                bytesSinceLastUpdate += bytesRead

                val now = System.currentTimeMillis()
                val elapsed = now - lastUpdateTime
                if (elapsed >= 300 || totalBytesRead == contentLength) {
                    val speedKbps = if (elapsed > 0) {
                        (bytesSinceLastUpdate * 1000L) / (elapsed * 1024L)
                    } else 0L

                    val progressPercent = if (contentLength > 0) {
                        ((totalBytesRead * 100) / contentLength).toInt().coerceIn(0, 100)
                    } else 0

                    stateFlow.value = ModelDownloadState.Downloading(
                        bytesDownloaded = totalBytesRead,
                        totalBytes = contentLength,
                        progressPercent = progressPercent,
                        speedKbps = speedKbps
                    )

                    lastUpdateTime = now
                    bytesSinceLastUpdate = 0L
                }
            }

            outputStream.flush()
            outputStream.close()
            inputStream.close()
            response.close()

            // Rename temp file to target file
            if (tempFile.exists()) {
                if (targetFile.exists()) targetFile.delete()
                if (!tempFile.renameTo(targetFile)) {
                    val errorMsg = "Failed to finalize downloaded model file"
                    onLog(errorMsg, true)
                    stateFlow.value = ModelDownloadState.Error(errorMsg)
                    return@withContext false
                }
            }

            model.isDownloaded = true
            model.localPath = targetFile.absolutePath
            stateFlow.value = ModelDownloadState.Completed(targetFile.length())
            onLog("Successfully downloaded ${model.name} (${targetFile.length() / (1024 * 1024)} MB) to offline storage", false)
            return@withContext true

        } catch (e: IOException) {
            val isCancelled = activeCalls[modelId]?.isCanceled() == true
            val errorMsg = if (isCancelled) "Download cancelled by user" else "Network error: ${e.localizedMessage ?: e.message}"
            onLog("Download failed: $errorMsg", true)
            stateFlow.value = ModelDownloadState.Error(errorMsg)
            if (tempFile.exists()) tempFile.delete()
            return@withContext false
        } catch (t: Throwable) {
            val errorMsg = "Unexpected error: ${t.localizedMessage ?: t.message}"
            onLog("Download error: $errorMsg", true)
            stateFlow.value = ModelDownloadState.Error(errorMsg)
            if (tempFile.exists()) tempFile.delete()
            return@withContext false
        } finally {
            activeCalls.remove(modelId)
        }
    }

    fun cancelDownload(modelId: String) {
        activeCalls[modelId]?.cancel()
        activeCalls.remove(modelId)
        val stateFlow = _downloadStates[modelId]
        stateFlow?.value = ModelDownloadState.Error("Cancelled")
        val model = availableModels.firstOrNull { it.id == modelId } ?: return
        val tempFile = File(modelsDir, "${model.fileName}.download")
        if (tempFile.exists()) tempFile.delete()
    }

    fun deleteModel(modelId: String): Boolean {
        val model = availableModels.firstOrNull { it.id == modelId } ?: return false
        val file = File(modelsDir, model.fileName)
        val deleted = if (file.exists()) file.delete() else false
        model.isDownloaded = false
        model.localPath = null
        _downloadStates[modelId]?.value = ModelDownloadState.Idle
        return deleted
    }

    /**
     * Check Hindi TextToSpeech engine availability and returns intent if voice pack download is needed.
     */
    fun checkHindiTtsStatus(tts: TextToSpeech?): TtsStatus {
        if (tts == null) return TtsStatus.Initializing

        val hindiLocale = Locale("hi", "IN")
        val result = tts.isLanguageAvailable(hindiLocale)

        return when (result) {
            TextToSpeech.LANG_AVAILABLE,
            TextToSpeech.LANG_COUNTRY_AVAILABLE,
            TextToSpeech.LANG_COUNTRY_VAR_AVAILABLE -> {
                TtsStatus.Available(hindiLocale)
            }
            TextToSpeech.LANG_MISSING_DATA -> {
                val installIntent = Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)
                TtsStatus.MissingData(installIntent)
            }
            TextToSpeech.LANG_NOT_SUPPORTED -> {
                TtsStatus.NotSupported
            }
            else -> TtsStatus.Unknown(result)
        }
    }

    sealed interface TtsStatus {
        data object Initializing : TtsStatus
        data class Available(val locale: Locale) : TtsStatus
        data class MissingData(val installIntent: Intent) : TtsStatus
        data object NotSupported : TtsStatus
        data class Unknown(val resultCode: Int) : TtsStatus
    }
}
