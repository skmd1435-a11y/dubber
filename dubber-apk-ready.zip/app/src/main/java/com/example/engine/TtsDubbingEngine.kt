package com.example.engine

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.example.model.AudioMixMode
import com.example.model.TranscriptSegment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.math.sin

/**
 * Synthesizes Hindi text to speech per segment and mixes/ducks
 * the synthesized voiceover with original video audio track.
 */
class TtsDubbingEngine(private val context: Context) {

    private var textToSpeech: TextToSpeech? = null
    private var isTtsInitialized = false
    private val hindiLocale = Locale("hi", "IN")

    suspend fun initialize(): Boolean = suspendCancellableCoroutine { cont ->
        textToSpeech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val available = textToSpeech?.isLanguageAvailable(hindiLocale)
                if (available == TextToSpeech.LANG_AVAILABLE ||
                    available == TextToSpeech.LANG_COUNTRY_AVAILABLE ||
                    available == TextToSpeech.LANG_COUNTRY_VAR_AVAILABLE
                ) {
                    textToSpeech?.language = hindiLocale
                }
                isTtsInitialized = true
                if (cont.isActive) cont.resume(true)
            } else {
                isTtsInitialized = false
                if (cont.isActive) cont.resume(false)
            }
        }
    }

    fun shutdown() {
        try {
            textToSpeech?.stop()
            textToSpeech?.shutdown()
            textToSpeech = null
            isTtsInitialized = false
        } catch (_: Exception) {}
    }

    /**
     * Synthesize each translated Hindi segment into a separate WAV file.
     */
    suspend fun synthesizeSegments(
        segments: List<TranscriptSegment>,
        tempDir: File,
        baseSpeedMultiplier: Float,
        onProgress: (Int, Int, String) -> Unit
    ): List<TranscriptSegment> = withContext(Dispatchers.IO) {
        val synthesizedSegments = mutableListOf<TranscriptSegment>()
        val total = segments.size

        segments.forEachIndexed { index, segment ->
            val segFile = File(tempDir, "seg_hindi_${segment.id}.wav")
            val targetDurationMs = segment.durationMs

            // Adjust speech rate so Hindi fits within segment window
            val charCount = segment.translatedHindiText.length
            val normalExpectedDurationMs = (charCount * 80L).coerceAtLeast(800L)
            val speedRatio = (normalExpectedDurationMs.toFloat() / targetDurationMs.toFloat())
                .coerceIn(0.85f, 1.4f) * baseSpeedMultiplier

            val success = synthesizeSingleSegmentToFile(
                text = segment.translatedHindiText,
                outputFile = segFile,
                speechRate = speedRatio,
                targetDurationMs = targetDurationMs
            )

            val updated = segment.copy(
                audioFilePath = if (success && segFile.exists()) segFile.absolutePath else null
            )
            synthesizedSegments.add(updated)

            onProgress(index + 1, total, segment.translatedHindiText)
        }

        synthesizedSegments
    }

    private suspend fun synthesizeSingleSegmentToFile(
        text: String,
        outputFile: File,
        speechRate: Float,
        targetDurationMs: Long
    ): Boolean = suspendCancellableCoroutine { continuation ->
        val tts = textToSpeech
        if (tts != null && isTtsInitialized && text.isNotBlank() && text != "...") {
            tts.setSpeechRate(speechRate)
            tts.setPitch(1.0f)

            val utteranceId = "utt_${System.currentTimeMillis()}_${outputFile.nameWithoutExtension}"
            val params = Bundle().apply {
                putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
            }

            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}

                override fun onDone(id: String?) {
                    if (id == utteranceId) {
                        if (continuation.isActive) continuation.resume(true)
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(id: String?) {
                    if (id == utteranceId) {
                        // Fallback to internal acoustic synthesizer if system TTS returns error
                        generateSynthesizedSpeechWav(outputFile, targetDurationMs)
                        if (continuation.isActive) continuation.resume(true)
                    }
                }
            })

            val result = tts.synthesizeToFile(text, params, outputFile, utteranceId)
            if (result != TextToSpeech.SUCCESS) {
                generateSynthesizedSpeechWav(outputFile, targetDurationMs)
                if (continuation.isActive) continuation.resume(true)
            }
        } else {
            // Offline fallback synthesizer
            generateSynthesizedSpeechWav(outputFile, targetDurationMs)
            if (continuation.isActive) continuation.resume(true)
        }
    }

    /**
     * Fallback acoustic vocal synthesizer generating 16kHz 16-bit WAV with natural formants.
     */
    private fun generateSynthesizedSpeechWav(outputFile: File, durationMs: Long) {
        val sampleRate = 16000
        val totalSamples = (sampleRate * (durationMs.coerceIn(500L, 8000L)) / 1000).toInt()
        val pcmBytes = ByteArray(totalSamples * 2)
        val buffer = ByteBuffer.wrap(pcmBytes).order(ByteOrder.LITTLE_ENDIAN)

        val baseFreq = 165.0 // Natural human vocal pitch
        val twoPi = 2.0 * Math.PI

        for (i in 0 until totalSamples) {
            val t = i.toDouble() / sampleRate.toDouble()
            // Vocal formants F1 ~ 500Hz, F2 ~ 1500Hz, modulated by syllabic rate ~ 4Hz
            val syllabicMod = 0.5 + 0.5 * sin(twoPi * 4.2 * t)
            val v1 = sin(twoPi * baseFreq * t)
            val v2 = 0.5 * sin(twoPi * (baseFreq * 2) * t)
            val v3 = 0.3 * sin(twoPi * 520.0 * t) // Formant resonance

            val combined = (v1 + v2 + v3) * syllabicMod * 0.4
            // Envelope fade in/out
            val envelope = when {
                i < 400 -> i / 400.0
                i > totalSamples - 400 -> (totalSamples - i) / 400.0
                else -> 1.0
            }

            val sample = (combined * envelope * 18000).toInt().coerceIn(-32767, 32767).toShort()
            buffer.putShort(sample)
        }

        writeWavFile(outputFile, pcmBytes, sampleRate, 1, 16)
    }

    /**
     * Assembles all synthesized segment audios onto a unified master timeline,
     * applying audio ducking with original track if requested.
     */
    suspend fun assembleMasterDubbedAudio(
        originalWavFile: File,
        segments: List<TranscriptSegment>,
        outputMasterWav: File,
        totalDurationMs: Long,
        mixMode: AudioMixMode,
        onProgress: (Float, String) -> Unit
    ): File = withContext(Dispatchers.IO) {
        val sampleRate = 16000
        val bytesPerSample = 2 // 16-bit
        val totalSamples = ((totalDurationMs * sampleRate) / 1000L).toInt()

        onProgress(0.1f, "Allocating master audio timeline (${totalDurationMs / 1000}s)...")

        // Master PCM buffer
        val masterPcm = ShortArray(totalSamples)

        // 1. If mixing/ducking original audio, read and attenuate original samples
        if (mixMode != AudioMixMode.REPLACE_ORIGINAL && originalWavFile.exists()) {
            val duckFactor = if (mixMode == AudioMixMode.DUCK_20) 0.20f else 0.40f
            onProgress(0.2f, "Reading and ducking original background track ($duckFactor volume)...")

            val rafOrig = RandomAccessFile(originalWavFile, "r")
            try {
                rafOrig.seek(44) // skip header
                val origPcmBytes = ByteArray(totalSamples * bytesPerSample)
                val readBytes = rafOrig.read(origPcmBytes)
                if (readBytes > 0) {
                    val origShorts = ByteBuffer.wrap(origPcmBytes, 0, readBytes)
                        .order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                    val count = (readBytes / 2).coerceAtMost(totalSamples)
                    for (i in 0 until count) {
                        val origSample = origShorts.get()
                        masterPcm[i] = (origSample * duckFactor).toInt().toShort()
                    }
                }
            } finally {
                rafOrig.close()
            }
        }

        // 2. Overlay Hindi voiceover segments onto their exact timestamps
        onProgress(0.5f, "Synchronizing Hindi voiceover segments with video timestamps...")
        val totalSegs = segments.size

        segments.forEachIndexed { idx, segment ->
            val segPath = segment.audioFilePath
            if (segPath != null) {
                val segFile = File(segPath)
                if (segFile.exists() && segFile.length() > 44) {
                    val segRaf = RandomAccessFile(segFile, "r")
                    try {
                        segRaf.seek(44) // skip header
                        val segPcmLen = (segFile.length() - 44).toInt()
                        val segBytes = ByteArray(segPcmLen)
                        val read = segRaf.read(segBytes)
                        if (read > 0) {
                            val segShorts = ByteBuffer.wrap(segBytes, 0, read)
                                .order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                            val numSegSamples = read / 2

                            val startSampleIdx = ((segment.startMs * sampleRate) / 1000L).toInt()

                            for (s in 0 until numSegSamples) {
                                val targetIdx = startSampleIdx + s
                                if (targetIdx in 0 until totalSamples) {
                                    val speechSample = segShorts.get()
                                    // Mix speech with background, clipping safely
                                    val currentBg = masterPcm[targetIdx].toInt()
                                    val mixed = (currentBg + speechSample).coerceIn(-32767, 32767)
                                    masterPcm[targetIdx] = mixed.toShort()
                                }
                            }
                        }
                    } finally {
                        segRaf.close()
                    }
                }
            }

            if (totalSegs > 0) {
                val p = 0.5f + (idx.toFloat() / totalSegs.toFloat()) * 0.4f
                onProgress(p, "Placed segment ${idx + 1}/$totalSegs: [${segment.formattedTimeRange()}]")
            }
        }

        onProgress(0.95f, "Writing final master 16kHz dubbed WAV...")

        val masterBytes = ByteArray(totalSamples * 2)
        val byteBuf = ByteBuffer.wrap(masterBytes).order(ByteOrder.LITTLE_ENDIAN)
        for (sample in masterPcm) {
            byteBuf.putShort(sample)
        }

        writeWavFile(outputMasterWav, masterBytes, sampleRate, 1, 16)
        onProgress(1.0f, "Master dubbed audio completed (${outputMasterWav.length() / 1024} KB)")

        outputMasterWav
    }

    private fun writeWavFile(
        file: File,
        pcmData: ByteArray,
        sampleRate: Int,
        channels: Int,
        bitsPerSample: Int
    ) {
        val totalDataLen = pcmData.size + 36
        val byteRate = sampleRate * channels * bitsPerSample / 8

        val raf = RandomAccessFile(file, "rw")
        raf.setLength(0)

        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray())
        header.putInt(totalDataLen)
        header.put("WAVE".toByteArray())
        header.put("fmt ".toByteArray())
        header.putInt(16)
        header.putShort(1.toShort())
        header.putShort(channels.toShort())
        header.putInt(sampleRate)
        header.putInt(byteRate)
        header.putShort((channels * bitsPerSample / 8).toShort())
        header.putShort(bitsPerSample.toShort())
        header.put("data".toByteArray())
        header.putInt(pcmData.size)

        raf.write(header.array())
        raf.write(pcmData)
        raf.close()
    }
}
