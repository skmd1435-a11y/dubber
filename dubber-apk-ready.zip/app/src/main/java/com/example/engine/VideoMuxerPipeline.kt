package com.example.engine

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Muxes original video frames with newly synthesized Hindi AAC audio,
 * and publishes the final dubbed video to Android's Movies/Dubbed gallery folder.
 */
class VideoMuxerPipeline(private val context: Context) {

    data class MuxResult(
        val localOutputFile: File,
        val galleryContentUri: Uri?,
        val fileName: String
    )

    suspend fun muxVideoWithNewAudio(
        videoUri: Uri,
        dubbedWavFile: File,
        outputMp4File: File,
        onProgress: (Float, String) -> Unit
    ): MuxResult = withContext(Dispatchers.IO) {
        val pfd = context.contentResolver.openFileDescriptor(videoUri, "r")
            ?: throw IllegalStateException("Cannot open input video descriptor")

        val videoExtractor = MediaExtractor()
        var muxer: MediaMuxer? = null
        var audioEncoder: MediaCodec? = null

        val sampleRate = 16000
        val channelCount = 1
        val audioBitrate = 96000

        try {
            videoExtractor.setDataSource(pfd.fileDescriptor)
            val trackCount = videoExtractor.trackCount
            var videoTrackIdx = -1
            var videoFormat: MediaFormat? = null

            for (i in 0 until trackCount) {
                val format = videoExtractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("video/")) {
                    videoTrackIdx = i
                    videoFormat = format
                    break
                }
            }

            if (videoTrackIdx == -1 || videoFormat == null) {
                throw IllegalStateException("Selected file does not have a valid video track")
            }

            videoExtractor.selectTrack(videoTrackIdx)

            if (outputMp4File.exists()) outputMp4File.delete()
            outputMp4File.parentFile?.mkdirs()

            muxer = MediaMuxer(outputMp4File.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

            // Add original video track directly to muxer
            val muxerVideoTrack = muxer.addTrack(videoFormat)

            // Setup AAC Audio Encoder for dubbed audio track
            val aacMime = MediaFormat.MIMETYPE_AUDIO_AAC
            val audioFormat = MediaFormat.createAudioFormat(aacMime, sampleRate, channelCount).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, audioBitrate)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            }

            audioEncoder = MediaCodec.createEncoderByType(aacMime)
            audioEncoder.configure(audioFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            audioEncoder.start()

            onProgress(0.1f, "Configured AAC encoder (96 kbps, 16kHz)...")

            // Encode a few dummy samples or wait until format is available, or add audio track
            // Let's determine audio output format from encoder
            var muxerAudioTrack = -1
            val bufferInfo = MediaCodec.BufferInfo()
            val timeoutUs = 10_000L

            // Feed initial PCM to get output format from encoder
            val wavRaf = RandomAccessFile(dubbedWavFile, "r")
            wavRaf.seek(44) // Skip header
            val pcmDataLength = (wavRaf.length() - 44).coerceAtLeast(0)

            var isPcmEOS = false
            var isAudioEncoderEOS = false
            var pcmBytesRead = 0L

            // Pump until encoder reports output format changed
            while (muxerAudioTrack == -1) {
                val inIdx = audioEncoder.dequeueInputBuffer(timeoutUs)
                if (inIdx >= 0) {
                    val inBuf = audioEncoder.getInputBuffer(inIdx)!!
                    val capacity = inBuf.capacity().coerceAtMost(4096)
                    val temp = ByteArray(capacity)
                    val read = wavRaf.read(temp)
                    if (read > 0) {
                        inBuf.clear()
                        inBuf.put(temp, 0, read)
                        val ptsUs = (pcmBytesRead * 1_000_000L) / (sampleRate * 2L)
                        pcmBytesRead += read
                        audioEncoder.queueInputBuffer(inIdx, 0, read, ptsUs, 0)
                    } else {
                        audioEncoder.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        isPcmEOS = true
                    }
                }

                val outIdx = audioEncoder.dequeueOutputBuffer(bufferInfo, timeoutUs)
                if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val newFormat = audioEncoder.outputFormat
                    muxerAudioTrack = muxer.addTrack(newFormat)
                } else if (outIdx >= 0) {
                    audioEncoder.releaseOutputBuffer(outIdx, false)
                }
            }

            onProgress(0.2f, "Starting MP4 container muxer...")
            muxer.start()

            // 1. Mux video samples
            onProgress(0.25f, "Writing video track to final container...")
            val maxVideoBufSize = if (videoFormat.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                videoFormat.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE).coerceAtLeast(1024 * 512)
            } else 1024 * 512

            val videoBuffer = ByteBuffer.allocate(maxVideoBufSize)
            val videoBufInfo = MediaCodec.BufferInfo()
            var videoSamplesWritten = 0

            while (true) {
                videoBuffer.clear()
                val sampleSize = videoExtractor.readSampleData(videoBuffer, 0)
                if (sampleSize < 0) {
                    break
                }

                videoBufInfo.offset = 0
                videoBufInfo.size = sampleSize
                videoBufInfo.presentationTimeUs = videoExtractor.sampleTime
                videoBufInfo.flags = videoExtractor.sampleFlags

                muxer.writeSampleData(muxerVideoTrack, videoBuffer, videoBufInfo)
                videoSamplesWritten++

                if (videoSamplesWritten % 100 == 0) {
                    onProgress(0.3f, "Transferred $videoSamplesWritten video frames...")
                }
                videoExtractor.advance()
            }

            onProgress(0.55f, "Encoding & muxing Hindi dubbed audio track...")

            // 2. Stream remaining PCM into AAC encoder and write to muxer
            while (!isAudioEncoderEOS) {
                if (!isPcmEOS) {
                    val inIdx = audioEncoder.dequeueInputBuffer(timeoutUs)
                    if (inIdx >= 0) {
                        val inBuf = audioEncoder.getInputBuffer(inIdx)!!
                        val capacity = inBuf.capacity().coerceAtMost(4096)
                        val temp = ByteArray(capacity)
                        val read = wavRaf.read(temp)
                        if (read > 0) {
                            inBuf.clear()
                            inBuf.put(temp, 0, read)
                            val ptsUs = (pcmBytesRead * 1_000_000L) / (sampleRate * 2L)
                            pcmBytesRead += read
                            audioEncoder.queueInputBuffer(inIdx, 0, read, ptsUs, 0)

                            if (pcmDataLength > 0) {
                                val ratio = 0.55f + (pcmBytesRead.toFloat() / pcmDataLength.toFloat()) * 0.35f
                                onProgress(ratio.coerceIn(0.55f, 0.90f), "Muxing audio: ${(pcmBytesRead / (sampleRate * 2L))}s")
                            }
                        } else {
                            audioEncoder.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            isPcmEOS = true
                        }
                    }
                }

                val outIdx = audioEncoder.dequeueOutputBuffer(bufferInfo, timeoutUs)
                if (outIdx >= 0) {
                    val encodedBuffer = audioEncoder.getOutputBuffer(outIdx)
                    if (encodedBuffer != null && bufferInfo.size > 0) {
                        if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                            muxer.writeSampleData(muxerAudioTrack, encodedBuffer, bufferInfo)
                        }
                    }
                    audioEncoder.releaseOutputBuffer(outIdx, false)

                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        isAudioEncoderEOS = true
                    }
                }
            }

            wavRaf.close()

            onProgress(0.92f, "Finalizing MP4 container...")
            muxer.stop()
            muxer.release()
            muxer = null

            // 3. Publish to Movies/Dubbed in MediaStore
            onProgress(0.96f, "Publishing dubbed video to Movies/Dubbed/ gallery...")
            val publishedUri = exportToMoviesGallery(outputMp4File)

            onProgress(1.0f, "Completed! Video saved to Gallery (Movies/Dubbed/)")

            MuxResult(
                localOutputFile = outputMp4File,
                galleryContentUri = publishedUri,
                fileName = outputMp4File.name
            )

        } finally {
            try {
                audioEncoder?.stop()
                audioEncoder?.release()
            } catch (_: Exception) {}
            try {
                videoExtractor.release()
            } catch (_: Exception) {}
            try {
                muxer?.release()
            } catch (_: Exception) {}
            try {
                pfd.close()
            } catch (_: Exception) {}
        }
    }

    private fun exportToMoviesGallery(file: File): Uri? {
        val resolver = context.contentResolver
        val contentValues = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.DATE_ADDED, System.currentTimeMillis() / 1000)
            put(MediaStore.Video.Media.DATE_MODIFIED, System.currentTimeMillis() / 1000)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Dubbed")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
        }

        val videoUri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, contentValues)
        if (videoUri != null) {
            try {
                resolver.openOutputStream(videoUri)?.use { out ->
                    FileInputStream(file).use { input ->
                        val buf = ByteArray(64 * 1024)
                        var r: Int
                        while (input.read(buf).also { r = it } != -1) {
                            out.write(buf, 0, r)
                        }
                    }
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    contentValues.clear()
                    contentValues.put(MediaStore.Video.Media.IS_PENDING, 0)
                    resolver.update(videoUri, contentValues, null, null)
                }
                return videoUri
            } catch (_: Exception) {
                return null
            }
        }
        return null
    }
}
