package com.example.model

import android.net.Uri
import java.io.File
import java.util.Locale

/**
 * Represents a single timestamped speech utterance segment in the video.
 */
data class TranscriptSegment(
    val id: Int,
    val startMs: Long,
    val endMs: Long,
    var sourceText: String,
    var translatedHindiText: String,
    var audioFilePath: String? = null,
    val detectedLanguage: String = "en"
) {
    val durationMs: Long get() = (endMs - startMs).coerceAtLeast(100L)

    fun formattedTimeRange(): String {
        return "${formatTime(startMs)} -> ${formatTime(endMs)}"
    }

    companion object {
        fun formatTime(ms: Long): String {
            val totalSeconds = ms / 1000
            val minutes = totalSeconds / 60
            val seconds = totalSeconds % 60
            val millis = ms % 1000
            return String.format(Locale.US, "%02d:%02d.%03d", minutes, seconds, millis)
        }
    }
}

/**
 * Metadata and download status of an offline AI model.
 */
data class ModelInfo(
    val id: String,
    val name: String,
    val category: String,
    val description: String,
    val downloadUrl: String,
    val fileName: String,
    val expectedSizeBytes: Long,
    var isDownloaded: Boolean = false,
    var localPath: String? = null
) {
    fun formattedExpectedSize(): String {
        val mb = expectedSizeBytes.toDouble() / (1024 * 1024)
        return String.format(Locale.US, "%.1f MB", mb)
    }
}

/**
 * Real-time download state for on-device models.
 */
sealed interface ModelDownloadState {
    data object Idle : ModelDownloadState
    data class Downloading(
        val bytesDownloaded: Long,
        val totalBytes: Long,
        val progressPercent: Int,
        val speedKbps: Long
    ) : ModelDownloadState
    data class Completed(val fileSize: Long) : ModelDownloadState
    data class Error(val message: String) : ModelDownloadState
}

/**
 * Audio mix strategy for the dubbed video.
 */
enum class AudioMixMode(val label: String, val description: String) {
    REPLACE_ORIGINAL(
        label = "Mute Original Audio",
        description = "Dubbed Hindi voiceover 100%, original audio muted"
    ),
    DUCK_20(
        label = "Ducked Background (20%)",
        description = "Hindi voiceover 100% + original video audio at 20% volume"
    ),
    DUCK_40(
        label = "Ducked Background (40%)",
        description = "Hindi voiceover 100% + original video audio at 40% volume"
    )
}

/**
 * Language options for speech detection.
 */
data class SupportedLanguage(
    val code: String,
    val name: String,
    val flag: String
)

/**
 * Current execution phase of the video dubbing pipeline.
 */
sealed interface DubbingStage {
    data object Idle : DubbingStage
    data class ExtractingAudio(val progress: Float, val detail: String) : DubbingStage
    data class SegmentingAudio(val progress: Float, val segmentCount: Int) : DubbingStage
    data class Transcribing(val current: Int, val total: Int, val snippet: String) : DubbingStage
    data class Translating(val current: Int, val total: Int, val snippet: String) : DubbingStage
    data class SynthesizingHindiTts(val current: Int, val total: Int, val snippet: String) : DubbingStage
    data class MixingAudio(val progress: Float, val detail: String) : DubbingStage
    data class MuxingVideo(val progress: Float, val detail: String) : DubbingStage
    data class Completed(
        val outputFile: File,
        val outputUri: Uri?,
        val durationMs: Long,
        val segmentCount: Int
    ) : DubbingStage
    data class Failed(val stageName: String, val error: String) : DubbingStage
}

/**
 * Real-time console log entry.
 */
data class LogEntry(
    val id: Long = System.currentTimeMillis(),
    val timestamp: String,
    val stage: String,
    val message: String,
    val isError: Boolean = false
)

/**
 * Video metadata for selected input.
 */
data class VideoMetadata(
    val uri: Uri,
    val fileName: String,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val sizeBytes: Long,
    val mimeType: String,
    val hasAudio: Boolean
) {
    fun formattedDuration(): String {
        val totalSec = durationMs / 1000
        val min = totalSec / 60
        val sec = totalSec % 60
        return String.format(Locale.US, "%02d:%02d", min, sec)
    }

    fun formattedSize(): String {
        val mb = sizeBytes.toDouble() / (1024 * 1024)
        return String.format(Locale.US, "%.1f MB", mb)
    }
}
