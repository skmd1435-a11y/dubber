package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.DubbingStage
import com.example.ui.components.DubbingConfigCard
import com.example.ui.components.HeroBannerCard
import com.example.ui.components.LiveConsoleLogCard
import com.example.ui.components.ModelDownloadCard
import com.example.ui.components.PipelineStageTracker
import com.example.ui.components.ResultVideoCard
import com.example.ui.components.SegmentInspectorCard
import com.example.ui.components.SetupInstructionsDialog
import com.example.ui.components.VideoPickerCard
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.SaffronPrimary
import com.example.viewmodel.DubberViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DubberScreen(
    viewModel: DubberViewModel = viewModel()
) {
    var showInstructionsDialog by remember { mutableStateOf(false) }

    val stage by viewModel.stage.collectAsState()
    val videoMeta by viewModel.videoMetadata.collectAsState()
    val segments by viewModel.segments.collectAsState()
    val logs by viewModel.liveLogs.collectAsState()
    val sourceLang by viewModel.selectedSourceLanguage.collectAsState()
    val detectedLang by viewModel.detectedLanguageResult.collectAsState()
    val mixMode by viewModel.audioMixMode.collectAsState()
    val voiceSpeed by viewModel.voiceSpeed.collectAsState()
    val selectedModelId by viewModel.selectedModelId.collectAsState()
    val playingSegmentId by viewModel.previewAudioPlayingSegmentId.collectAsState()

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Translate,
                            contentDescription = null,
                            tint = SaffronPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Video Language Dubber",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = DarkSurface
                )
            )
        },
        containerColor = DarkSurface
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(DarkSurface),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Hero Banner Card
            item {
                HeroBannerCard(
                    onOpenInstructions = { showInstructionsDialog = true }
                )
            }

            // 2. On-Device AI Models Manager
            item {
                ModelDownloadCard(
                    modelManager = viewModel.modelManager,
                    onDownloadModel = { viewModel.downloadModel(it) },
                    onCancelDownload = { viewModel.cancelModelDownload(it) },
                    onDeleteModel = { viewModel.deleteModel(it) }
                )
            }

            // 3. Video Picker Card
            item {
                VideoPickerCard(
                    videoMetadata = videoMeta,
                    onVideoSelected = { viewModel.selectVideo(it) }
                )
            }

            // 4. Dubbing Configuration Card
            item {
                DubbingConfigCard(
                    supportedLanguages = viewModel.supportedLanguages,
                    selectedSourceLanguage = sourceLang,
                    onSelectSourceLanguage = { viewModel.setSourceLanguage(it) },
                    audioMixMode = mixMode,
                    onSelectMixMode = { viewModel.setAudioMixMode(it) },
                    voiceSpeed = voiceSpeed,
                    onChangeVoiceSpeed = { viewModel.setVoiceSpeed(it) },
                    selectedModelId = selectedModelId,
                    onSelectModelId = { viewModel.setSelectedModelId(it) },
                    currentStage = stage,
                    hasVideoSelected = videoMeta != null,
                    onStartDubbing = { viewModel.startDubbingPipeline() },
                    onCancelDubbing = { viewModel.cancelDubbing() }
                )
            }

            // 5. Result Video Card (When Finished)
            if (stage is DubbingStage.Completed) {
                item {
                    ResultVideoCard(result = stage as DubbingStage.Completed)
                }
            }

            // 6. Pipeline Stage Tracker (When Processing)
            if (stage !is DubbingStage.Idle) {
                item {
                    PipelineStageTracker(
                        currentStage = stage,
                        detectedLanguage = detectedLang
                    )
                }
            }

            // 7. Dubbed Segment Inspector (When segments are available)
            if (segments.isNotEmpty()) {
                item {
                    SegmentInspectorCard(
                        segments = segments,
                        playingSegmentId = playingSegmentId,
                        onPlaySegment = { viewModel.playSegmentPreview(it) },
                        onStopSegment = { viewModel.stopSegmentPreview() }
                    )
                }
            }

            // 8. Live Console Logs Card
            item {
                LiveConsoleLogCard(
                    logs = logs,
                    onClearLogs = { viewModel.clearLogs() }
                )
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    if (showInstructionsDialog) {
        SetupInstructionsDialog(onDismiss = { showInstructionsDialog = false })
    }
}
