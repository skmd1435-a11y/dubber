package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Pending
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.DubbingStage
import com.example.ui.theme.SaffronPrimary
import com.example.ui.theme.StudioCardBg
import com.example.ui.theme.StudioCardBorder
import com.example.ui.theme.StudioError
import com.example.ui.theme.StudioSuccess
import com.example.ui.theme.WaveformCyan

enum class StepState { PENDING, ACTIVE, COMPLETED, FAILED }

data class PipelineStep(
    val id: Int,
    val title: String,
    val description: String
)

@Composable
fun PipelineStageTracker(
    currentStage: DubbingStage,
    detectedLanguage: String?,
    modifier: Modifier = Modifier
) {
    if (currentStage is DubbingStage.Idle) return

    val steps = listOf(
        PipelineStep(1, "Extract Audio", "Decode video audio to 16kHz PCM WAV"),
        PipelineStep(2, "Voice Segmentation", "VAD analysis and utterance chunking"),
        PipelineStep(3, "Language Detection & STT", "Identify language & transcribe speech"),
        PipelineStep(4, "Neural Translation", "Translate utterances into fluent Hindi"),
        PipelineStep(5, "Hindi TTS Synthesis", "Generate voiceover audio per timestamp"),
        PipelineStep(6, "Master Audio Mixing", "Synchronize speech & apply audio ducking"),
        PipelineStep(7, "Video Remuxing", "AAC audio encoding & MP4 muxing")
    )

    val activeStepIndex = when (currentStage) {
        is DubbingStage.Idle -> -1
        is DubbingStage.ExtractingAudio -> 0
        is DubbingStage.SegmentingAudio -> 1
        is DubbingStage.Transcribing -> 2
        is DubbingStage.Translating -> 3
        is DubbingStage.SynthesizingHindiTts -> 4
        is DubbingStage.MixingAudio -> 5
        is DubbingStage.MuxingVideo -> 6
        is DubbingStage.Completed -> 7
        is DubbingStage.Failed -> -2
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("pipeline_stage_tracker"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = StudioCardBg),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(StudioCardBorder))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Title & Overall Progress
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Dubbing Pipeline Progress",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                if (currentStage is DubbingStage.Completed) {
                    Text("100%", color = StudioSuccess, fontWeight = FontWeight.Bold)
                } else if (activeStepIndex in 0..6) {
                    val percent = ((activeStepIndex.toFloat() / 7f) * 100).toInt()
                    Text("$percent%", color = SaffronPrimary, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Overall Progress Bar
            val overallProgress = when (currentStage) {
                is DubbingStage.Completed -> 1.0f
                is DubbingStage.ExtractingAudio -> 0.05f + currentStage.progress * 0.10f
                is DubbingStage.SegmentingAudio -> 0.15f + currentStage.progress * 0.10f
                is DubbingStage.Transcribing -> {
                    val ratio = if (currentStage.total > 0) currentStage.current.toFloat() / currentStage.total else 0f
                    0.25f + ratio * 0.20f
                }
                is DubbingStage.Translating -> {
                    val ratio = if (currentStage.total > 0) currentStage.current.toFloat() / currentStage.total else 0f
                    0.45f + ratio * 0.15f
                }
                is DubbingStage.SynthesizingHindiTts -> {
                    val ratio = if (currentStage.total > 0) currentStage.current.toFloat() / currentStage.total else 0f
                    0.60f + ratio * 0.15f
                }
                is DubbingStage.MixingAudio -> 0.75f + currentStage.progress * 0.10f
                is DubbingStage.MuxingVideo -> 0.85f + currentStage.progress * 0.14f
                else -> 0f
            }

            LinearProgressIndicator(
                progress = { overallProgress.coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = if (currentStage is DubbingStage.Completed) StudioSuccess else SaffronPrimary,
                trackColor = Color(0xFF0F172A)
            )

            // Current Active Detail message
            val activeDetail = when (currentStage) {
                is DubbingStage.ExtractingAudio -> currentStage.detail
                is DubbingStage.SegmentingAudio -> "Analyzing energy & segmenting audio (${currentStage.segmentCount} chunks)"
                is DubbingStage.Transcribing -> "Transcribing speech: [${currentStage.current}/${currentStage.total}] \"${currentStage.snippet}\""
                is DubbingStage.Translating -> "Translating to Hindi: [${currentStage.current}/${currentStage.total}] \"${currentStage.snippet}\""
                is DubbingStage.SynthesizingHindiTts -> "Synthesizing Hindi: [${currentStage.current}/${currentStage.total}] \"${currentStage.snippet}\""
                is DubbingStage.MixingAudio -> currentStage.detail
                is DubbingStage.MuxingVideo -> currentStage.detail
                is DubbingStage.Completed -> "Successfully muxed and saved to Movies/Dubbed/!"
                is DubbingStage.Failed -> "Pipeline failed: ${currentStage.error}"
                else -> ""
            }

            if (activeDetail.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF0F172A))
                        .padding(8.dp)
                ) {
                    Text(
                        text = activeDetail,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (currentStage is DubbingStage.Failed) StudioError else WaveformCyan,
                        maxLines = 2
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Step Items
            steps.forEachIndexed { index, step ->
                val state = when {
                    currentStage is DubbingStage.Completed -> StepState.COMPLETED
                    currentStage is DubbingStage.Failed && index == activeStepIndex -> StepState.FAILED
                    index < activeStepIndex -> StepState.COMPLETED
                    index == activeStepIndex -> StepState.ACTIVE
                    else -> StepState.PENDING
                }

                StepRow(
                    stepNumber = index + 1,
                    title = step.title,
                    description = if (index == 2 && detectedLanguage != null) {
                        "Detected: $detectedLanguage"
                    } else step.description,
                    state = state
                )
                if (index < steps.size - 1) {
                    Spacer(modifier = Modifier.height(6.dp))
                }
            }
        }
    }
}

@Composable
fun StepRow(
    stepNumber: Int,
    title: String,
    description: String,
    state: StepState
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Icon / Indicator
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(
                    when (state) {
                        StepState.COMPLETED -> StudioSuccess.copy(alpha = 0.2f)
                        StepState.ACTIVE -> SaffronPrimary.copy(alpha = 0.2f)
                        StepState.FAILED -> StudioError.copy(alpha = 0.2f)
                        StepState.PENDING -> Color(0xFF0F172A)
                    }
                ),
            contentAlignment = Alignment.Center
        ) {
            when (state) {
                StepState.COMPLETED -> Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Completed",
                    tint = StudioSuccess,
                    modifier = Modifier.size(18.dp)
                )
                StepState.ACTIVE -> CircularProgressIndicator(
                    modifier = Modifier.size(16.dp),
                    color = SaffronPrimary,
                    strokeWidth = 2.dp
                )
                StepState.FAILED -> Icon(
                    imageVector = Icons.Default.Error,
                    contentDescription = "Failed",
                    tint = StudioError,
                    modifier = Modifier.size(18.dp)
                )
                StepState.PENDING -> Text(
                    text = "$stepNumber",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF64748B)
                )
            }
        }

        Spacer(modifier = Modifier.width(10.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = if (state == StepState.ACTIVE) FontWeight.Bold else FontWeight.Medium,
                color = when (state) {
                    StepState.ACTIVE -> SaffronPrimary
                    StepState.COMPLETED -> Color.White
                    StepState.FAILED -> StudioError
                    StepState.PENDING -> Color(0xFF94A3B8)
                }
            )
            Text(
                text = description,
                style = MaterialTheme.typography.labelSmall,
                color = Color(0xFF64748B)
            )
        }
    }
}
