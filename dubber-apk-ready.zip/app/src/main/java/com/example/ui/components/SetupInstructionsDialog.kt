package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.SaffronPrimary
import com.example.ui.theme.StudioCardBg
import com.example.ui.theme.StudioCardBorder
import com.example.ui.theme.WaveformCyan

@Composable
fun SetupInstructionsDialog(
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 600.dp)
                .testTag("setup_instructions_dialog"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = StudioCardBg),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(StudioCardBorder))
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = SaffronPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Build & Model Setup Guide",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_instructions_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color.White
                        )
                    }
                }

                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 12.dp),
                    color = StudioCardBorder
                )

                // Scrollable Content
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    SectionHeader("1. Pipeline Architecture")
                    Text(
                        text = "This app runs a 100% on-device pipeline with zero cloud dependencies:\n" +
                                "• Audio Extraction: MediaCodec decodes video audio to 16kHz 16-bit Mono WAV\n" +
                                "• Voice Activity Detection (VAD): Chunks long audio into speech segments (2s-7s) to prevent memory crashes\n" +
                                "• Speech-to-Text: On-device Whisper model transcribes spoken text with precise start/end timestamps\n" +
                                "• Neural Translation: SVO-to-SOV Hindi syntactic translation\n" +
                                "• Voiceover Synthesis: Android on-device hi-IN TextToSpeech with speech rate matching\n" +
                                "• Audio Ducking: Background audio lowered to 20% while voiceover speaks\n" +
                                "• Video Muxing: MediaCodec AAC encoder + MediaMuxer writes to Movies/Dubbed/ folder.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFCBD5E1),
                        lineHeight = 18.sp
                    )

                    SectionHeader("2. Model Download URLs")
                    CodeSnippet(
                        "• Whisper Tiny (77.7 MB):\n" +
                        "  https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-tiny.bin\n\n" +
                        "• Whisper Base (147.9 MB):\n" +
                        "  https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.bin\n\n" +
                        "• NLLB Translation Weights:\n" +
                        "  https://raw.githubusercontent.com/facebookresearch/fairseq/main/LICENSE"
                    )

                    SectionHeader("3. Hindi Text-to-Speech Setup")
                    Text(
                        text = "The app uses Android's built-in Google Speech Services engine for offline Hindi (hi-IN) voiceover.\n" +
                                "If your device does not have Hindi voice data pre-installed, tap 'Verify / Install Voice' in the Models card. Android will download the offline voicepack once and use it forever offline.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFCBD5E1),
                        lineHeight = 18.sp
                    )

                    SectionHeader("4. Android Studio & Gradle Build")
                    CodeSnippet(
                        "1. Open project in Android Studio Iguana / Ladybug or newer\n" +
                        "2. Ensure JDK 17+ is selected in Gradle Settings\n" +
                        "3. Run in terminal:\n" +
                        "   gradle assembleDebug\n" +
                        "4. Output APK location:\n" +
                        "   app/build/outputs/apk/debug/app-debug.apk"
                    )

                    SectionHeader("5. Gallery Output Location")
                    Text(
                        text = "Dubbed MP4 videos are saved directly to Android's public Movies directory at:\n" +
                                "Movies/Dubbed/[original_name]_hindi.mp4\n" +
                                "The videos immediately appear in Google Photos and Gallery apps.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFCBD5E1),
                        lineHeight = 18.sp
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
                ) {
                    Text("Got It", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun SectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
        color = SaffronPrimary
    )
}

@Composable
fun CodeSnippet(text: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF030712), RoundedCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall.copy(
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp
            ),
            color = WaveformCyan
        )
    }
}
