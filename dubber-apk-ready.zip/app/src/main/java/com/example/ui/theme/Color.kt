package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Video Dubbing Studio Color Palette
val StudioNavy = Color(0xFF0F172A)
val StudioCardBg = Color(0xFF1E293B)
val StudioCardBorder = Color(0xFF334155)

// Hindi Saffron & Amber accents
val SaffronPrimary = Color(0xFFFF9933)
val SaffronDark = Color(0xFFE67300)
val AmberAccent = Color(0xFFFBBF24)

// Audio Waveform Cyan
val WaveformCyan = Color(0xFF38BDF8)
val WaveformTeal = Color(0xFF2DD4BF)

// Success & Pipeline Colors
val StudioSuccess = Color(0xFF10B981)
val StudioError = Color(0xFFEF4444)
val StudioWarning = Color(0xFFF59E0B)

// Surface colors
val DarkSurface = Color(0xFF0B1120)
val DarkSurfaceVariant = Color(0xFF1E293B)
val OnDarkSurface = Color(0xFFF8FAFC)
val OnDarkSurfaceMuted = Color(0xFF94A3B8)
