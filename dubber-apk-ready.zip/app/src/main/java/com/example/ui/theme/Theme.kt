package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val StudioDarkColorScheme = darkColorScheme(
    primary = SaffronPrimary,
    onPrimary = Color.Black,
    primaryContainer = SaffronDark,
    onPrimaryContainer = Color.White,
    secondary = WaveformCyan,
    onSecondary = Color.Black,
    secondaryContainer = StudioCardBorder,
    onSecondaryContainer = OnDarkSurface,
    tertiary = WaveformTeal,
    background = DarkSurface,
    onBackground = OnDarkSurface,
    surface = DarkSurfaceVariant,
    onSurface = OnDarkSurface,
    surfaceVariant = StudioCardBg,
    onSurfaceVariant = OnDarkSurfaceMuted
)

private val StudioLightColorScheme = lightColorScheme(
    primary = SaffronDark,
    onPrimary = Color.White,
    primaryContainer = SaffronPrimary,
    onPrimaryContainer = Color.Black,
    secondary = Color(0xFF0284C7),
    onSecondary = Color.White,
    background = Color(0xFFF8FAFC),
    onBackground = Color(0xFF0F172A),
    surface = Color.White,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = Color(0xFF475569)
)

@Composable
fun VideoDubberTheme(
    darkTheme: Boolean = true, // Default to dark studio theme for video dubbing
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> StudioDarkColorScheme
        else -> StudioLightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
