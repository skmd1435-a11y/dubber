package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.engine.AudioChunker
import com.example.engine.AudioExtractor
import com.example.engine.ModelManager
import com.example.engine.TtsDubbingEngine
import com.example.engine.TranscriptionEngine
import com.example.engine.TranslationEngine
import com.example.engine.VideoMuxerPipeline
import com.example.model.AudioMixMode
import com.example.model.DubbingStage
import com.example.model.LogEntry
import com.example.model.ModelInfo
import com.example.model.SupportedLanguage
import com.example.model.TranscriptSegment
import com.example.model.VideoMetadata
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DubberViewModel(application: Application) : AndroidViewModel(application) {

    private val context: Context get() = getApplication<Application>().applicationContext

    val modelManager = ModelManager(context)
    private val audioExtractor = AudioExtractor(context)
    private val audioChunker = AudioChunker()
    private val transcriptionEngine = TranscriptionEngine(context, modelManager)
    private val translationEngine = TranslationEngine(modelManager)
    private val ttsDubbingEngine = TtsDubbingEngine(context)
    private val videoMuxerPipeline = VideoMuxerPipeline(context)

    private val timeFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    // UI States
    private val _stage = MutableStateFlow<DubbingStage>(DubbingStage.Idle)
    val stage: StateFlow<DubbingStage> = _stage.asStateFlow()

    private val _videoMetadata = MutableStateFlow<VideoMetadata?>(null)
    val videoMetadata: StateFlow<VideoMetadata?> = _videoMetadata.asStateFlow()

    private val _segments = MutableStateFlow<List<TranscriptSegment>>(emptyList())
    val segments: StateFlow<List<TranscriptSegment>> = _segments.asStateFlow()

    private val _liveLogs = MutableStateFlow<List<LogEntry>>(emptyList())
    val liveLogs: StateFlow<List<LogEntry>> = _liveLogs.asStateFlow()

    private val _selectedSourceLanguage = MutableStateFlow("Auto Detect")
    val selectedSourceLanguage: StateFlow<String> = _selectedSourceLanguage.asStateFlow()

    private val _detectedLanguageResult = MutableStateFlow<String?>(null)
    val detectedLanguageResult: StateFlow<String?> = _detectedLanguageResult.asStateFlow()

    private val _audioMixMode = MutableStateFlow(AudioMixMode.DUCK_20)
    val audioMixMode: StateFlow<AudioMixMode> = _audioMixMode.asStateFlow()

    private val _voiceSpeed = MutableStateFlow(1.0f)
    val voiceSpeed: StateFlow<Float> = _voiceSpeed.asStateFlow()

    private val _selectedModelId = MutableStateFlow("whisper-tiny")
    val selectedModelId: StateFlow<String> = _selectedModelId.asStateFlow()

    private val _previewAudioPlayingSegmentId = MutableStateFlow<Int?>(null)
    val previewAudioPlayingSegmentId: StateFlow<Int?> = _previewAudioPlayingSegmentId.asStateFlow()

    private var activeJob: Job? = null
    private var segmentMediaPlayer: MediaPlayer? = null

    val supportedLanguages = listOf(
        SupportedLanguage("auto", "Auto Detect", "🌐"),
        SupportedLanguage("en", "English", "🇺🇸"),
        SupportedLanguage("ko", "Korean", "🇰🇷"),
        SupportedLanguage("es", "Spanish", "🇪🇸"),
        SupportedLanguage("ja", "Japanese", "🇯🇵"),
        SupportedLanguage("fr", "French", "🇫🇷"),
        SupportedLanguage("de", "German", "🇩🇪"),
        SupportedLanguage("ru", "Russian", "🇷🇺"),
        SupportedLanguage("zh", "Chinese", "🇨🇳"),
        SupportedLanguage("ar", "Arabic", "🇸🇦")
    )

    init {
        log("INIT", "Video Language Dubber engine initialized. Ready for offline processing.")
        viewModelScope.launch {
            ttsDubbingEngine.initialize()
            log("TTS", "On-device TextToSpeech engine initialized.")
        }
    }

    fun setSourceLanguage(lang: String) {
        _selectedSourceLanguage.value = lang
        log("CONFIG", "Spoken language preference set to: $lang")
    }

    fun setAudioMixMode(mode: AudioMixMode) {
        _audioMixMode.value = mode
        log("CONFIG", "Audio mix mode set to: ${mode.label}")
    }

    fun setVoiceSpeed(speed: Float) {
        _voiceSpeed.value = speed
    }

    fun setSelectedModelId(modelId: String) {
        _selectedModelId.value = modelId
        log("CONFIG", "Speech recognition model set to: $modelId")
    }

    fun selectVideo(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                log("FILE", "Inspecting chosen video URI: $uri")
                val meta = extractVideoMetadata(uri)
                _videoMetadata.value = meta
                _segments.value = emptyList()
                _detectedLanguageResult.value = null
                _stage.value = DubbingStage.Idle
                log("FILE", "Loaded: ${meta.fileName} (${meta.formattedDuration()}, ${meta.width}x${meta.height}, ${meta.formattedSize()})")
            } catch (e: Exception) {
                log("FILE", "Error inspecting video: ${e.localizedMessage}", true)
            }
        }
    }

    private fun extractVideoMetadata(uri: Uri): VideoMetadata {
        val retriever = MediaMetadataRetriever()
        var durationMs = 0L
        var width = 0
        var height = 0
        var mime = "video/mp4"
        var hasAudio = false

        try {
            retriever.setDataSource(context, uri)
            durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 1280
            height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 720
            mime = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE) ?: "video/mp4"
            hasAudio = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO) == "yes"
        } catch (_: Exception) {} finally {
            try { retriever.release() } catch (_: Exception) {}
        }

        var fileName = "video_${System.currentTimeMillis()}.mp4"
        var sizeBytes = 0L
        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (cursor.moveToFirst()) {
                    if (nameIdx >= 0) fileName = cursor.getString(nameIdx) ?: fileName
                    if (sizeIdx >= 0) sizeBytes = cursor.getLong(sizeIdx)
                }
            }
        } catch (_: Exception) {}

        return VideoMetadata(
            uri = uri,
            fileName = fileName,
            durationMs = durationMs,
            width = width,
            height = height,
            sizeBytes = sizeBytes,
            mimeType = mime,
            hasAudio = hasAudio
        )
    }

    fun startDubbingPipeline() {
        val meta = _videoMetadata.value ?: run {
            log("PIPELINE", "Cannot start: No video selected", true)
            return
        }

        activeJob?.cancel()
        activeJob = viewModelScope.launch(Dispatchers.Default) {
            val workDir = File(context.cacheDir, "dubbing_session_${System.currentTimeMillis()}").apply { mkdirs() }
            val extractedWav = File(workDir, "extracted_audio.wav")
            val masterDubbedWav = File(workDir, "master_dubbed.wav")
            val outputMp4 = File(workDir, "dubbed_${meta.fileName.substringBeforeLast('.')}_hindi.mp4")

            try {
                log("PIPELINE", "================ STARTING DUBBING PIPELINE ================")
                log("PIPELINE", "Target: Translate and dub '${meta.fileName}' into natural Hindi")

                // STAGE 1: Audio Extraction
                _stage.value = DubbingStage.ExtractingAudio(0.0f, "Initializing MediaCodec audio extractor...")
                log("EXTRACT", "Extracting and resampling audio to 16,000 Hz 16-bit PCM WAV...")

                val extractionResult = audioExtractor.extractAudioToWav(
                    videoUri = meta.uri,
                    outputWavFile = extractedWav,
                    onProgress = { p, detail ->
                        _stage.value = DubbingStage.ExtractingAudio(p, detail)
                    }
                )
                log("EXTRACT", "Audio extraction complete. Duration: ${extractionResult.durationMs / 1000}s, Waveform points: ${extractionResult.waveformAmplitudes.size}")

                // STAGE 2: Audio Chunking & VAD
                _stage.value = DubbingStage.SegmentingAudio(0.0f, 0)
                log("VAD", "Analyzing acoustic energy with Voice Activity Detection (chunking long audio)...")

                val rawSegments = audioChunker.segmentAudioWav(
                    wavFile = extractedWav,
                    totalDurationMs = extractionResult.durationMs,
                    onProgress = { p, count ->
                        _stage.value = DubbingStage.SegmentingAudio(p, count)
                    }
                )
                log("VAD", "Detected ${rawSegments.size} conversation speech segments with timestamps.")

                // STAGE 3: Language Detection & Whisper STT
                log("DETECT", "Detecting spoken language automatically...")
                val detectResult = transcriptionEngine.detectSpokenLanguage(
                    wavFile = extractedWav,
                    targetModelId = _selectedModelId.value,
                    manualSelection = _selectedSourceLanguage.value
                )
                _detectedLanguageResult.value = "${detectResult.languageName} (${(detectResult.confidence * 100).toInt()}%)"
                log("DETECT", "Detected language: ${detectResult.languageName} [code: ${detectResult.languageCode}], confidence: ${(detectResult.confidence * 100).toInt()}%")

                _stage.value = DubbingStage.Transcribing(0, rawSegments.size, "Starting offline transcription...")
                log("WHISPER", "Transcribing speech segments using offline Whisper model (${_selectedModelId.value})...")

                val transcribed = transcriptionEngine.transcribeSegments(
                    wavFile = extractedWav,
                    segments = rawSegments,
                    detectedLanguageCode = detectResult.languageCode,
                    modelId = _selectedModelId.value,
                    onProgress = { curr, total, snippet ->
                        _stage.value = DubbingStage.Transcribing(curr, total, snippet)
                        log("WHISPER", "Segment $curr/$total: \"$snippet\"")
                    }
                )
                _segments.value = transcribed

                // STAGE 4: Translation to Hindi
                _stage.value = DubbingStage.Translating(0, transcribed.size, "Starting neural translation to Hindi...")
                log("TRANSLATE", "Translating ${transcribed.size} segments into natural Hindi (SOV syntax)...")

                val translated = translationEngine.translateSegments(
                    segments = transcribed,
                    onProgress = { curr, total, snippet ->
                        _stage.value = DubbingStage.Translating(curr, total, snippet)
                        log("TRANSLATE", "Segment $curr/$total -> \"$snippet\"")
                    }
                )
                _segments.value = translated

                // STAGE 5: Hindi TTS Voiceover per segment
                _stage.value = DubbingStage.SynthesizingHindiTts(0, translated.size, "Synthesizing Hindi speech...")
                log("TTS", "Generating natural Hindi voiceover audio per timestamp with speech rate normalization...")

                val synthesized = ttsDubbingEngine.synthesizeSegments(
                    segments = translated,
                    tempDir = workDir,
                    baseSpeedMultiplier = _voiceSpeed.value,
                    onProgress = { curr, total, snippet ->
                        _stage.value = DubbingStage.SynthesizingHindiTts(curr, total, snippet)
                        log("TTS", "Synthesized voiceover $curr/$total: \"$snippet\"")
                    }
                )
                _segments.value = synthesized

                // STAGE 6: Master Dubbed Audio Mixing & Ducking
                _stage.value = DubbingStage.MixingAudio(0.0f, "Assembling master dubbed audio track...")
                log("MIX", "Mixing audio tracks with ${_audioMixMode.value.label}...")

                ttsDubbingEngine.assembleMasterDubbedAudio(
                    originalWavFile = extractedWav,
                    segments = synthesized,
                    outputMasterWav = masterDubbedWav,
                    totalDurationMs = extractionResult.durationMs,
                    mixMode = _audioMixMode.value,
                    onProgress = { p, detail ->
                        _stage.value = DubbingStage.MixingAudio(p, detail)
                        if (p >= 0.95f) log("MIX", detail)
                    }
                )

                // STAGE 7: Video Muxing (AAC Encode + MP4 Container Mux)
                _stage.value = DubbingStage.MuxingVideo(0.0f, "Muxing video with new Hindi audio track...")
                log("MUX", "Encoding dubbed audio to AAC and interleaving video frames into final MP4...")

                val muxResult = videoMuxerPipeline.muxVideoWithNewAudio(
                    videoUri = meta.uri,
                    dubbedWavFile = masterDubbedWav,
                    outputMp4File = outputMp4,
                    onProgress = { p, detail ->
                        _stage.value = DubbingStage.MuxingVideo(p, detail)
                    }
                )

                log("PIPELINE", "SUCCESS! Dubbed video created: ${muxResult.fileName}")
                if (muxResult.galleryContentUri != null) {
                    log("PIPELINE", "Exported to Movies/Dubbed/ in Gallery. Ready for viewing.")
                }

                _stage.value = DubbingStage.Completed(
                    outputFile = muxResult.localOutputFile,
                    outputUri = muxResult.galleryContentUri,
                    durationMs = extractionResult.durationMs,
                    segmentCount = synthesized.size
                )

            } catch (e: Exception) {
                val errorMsg = e.localizedMessage ?: e.message ?: "Unknown pipeline failure"
                log("ERROR", "Pipeline failed: $errorMsg", true)
                _stage.value = DubbingStage.Failed("Dubbing Pipeline", errorMsg)
            }
        }
    }

    fun cancelDubbing() {
        activeJob?.cancel()
        activeJob = null
        _stage.value = DubbingStage.Idle
        log("PIPELINE", "Dubbing process cancelled by user.")
    }

    fun playSegmentPreview(segment: TranscriptSegment) {
        val audioPath = segment.audioFilePath ?: return
        val audioFile = File(audioPath)
        if (!audioFile.exists()) return

        stopSegmentPreview()

        try {
            segmentMediaPlayer = MediaPlayer().apply {
                setDataSource(audioFile.absolutePath)
                prepare()
                setOnCompletionListener {
                    _previewAudioPlayingSegmentId.value = null
                }
                start()
            }
            _previewAudioPlayingSegmentId.value = segment.id
            log("AUDIO", "Playing preview for Segment #${segment.id}: \"${segment.translatedHindiText}\"")
        } catch (e: Exception) {
            log("AUDIO", "Error playing preview: ${e.localizedMessage}", true)
            _previewAudioPlayingSegmentId.value = null
        }
    }

    fun stopSegmentPreview() {
        try {
            segmentMediaPlayer?.stop()
            segmentMediaPlayer?.release()
            segmentMediaPlayer = null
        } catch (_: Exception) {}
        _previewAudioPlayingSegmentId.value = null
    }

    fun downloadModel(model: ModelInfo) {
        viewModelScope.launch {
            log("MODEL", "Triggering download for: ${model.name}")
            modelManager.downloadModel(model.id) { msg, isErr ->
                log("MODEL", msg, isErr)
            }
        }
    }

    fun cancelModelDownload(modelId: String) {
        modelManager.cancelDownload(modelId)
        log("MODEL", "Download cancelled for $modelId")
    }

    fun deleteModel(modelId: String) {
        val deleted = modelManager.deleteModel(modelId)
        if (deleted) {
            log("MODEL", "Deleted offline model: $modelId")
        }
    }

    fun clearLogs() {
        _liveLogs.value = emptyList()
    }

    fun log(stage: String, message: String, isError: Boolean = false) {
        val time = timeFormat.format(Date())
        val entry = LogEntry(
            timestamp = time,
            stage = stage,
            message = message,
            isError = isError
        )
        val current = _liveLogs.value.toMutableList()
        current.add(entry)
        if (current.size > 200) {
            current.removeAt(0)
        }
        _liveLogs.value = current
    }

    override fun onCleared() {
        super.onCleared()
        stopSegmentPreview()
        ttsDubbingEngine.shutdown()
    }
}
