package com.example

import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * Basic test verification.
 */
class ExampleRobolectricTest {

    @Test
    fun placeholder_test() {
        assertEquals("Video Dubber", "Video Dubber")
    }
}
