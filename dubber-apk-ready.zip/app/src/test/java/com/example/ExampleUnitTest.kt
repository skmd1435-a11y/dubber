package com.example

import com.example.model.AudioMixMode
import com.example.model.TranscriptSegment
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Local JVM unit tests for video dubbing models, segment math, and audio mix modes.
 */
class ExampleUnitTest {

    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun transcriptSegment_formattingAndDuration() {
        val segment = TranscriptSegment(
            id = 1,
            startMs = 1200L,
            endMs = 4500L,
            sourceText = "Hello everyone, welcome to the video.",
            translatedHindiText = "सभी को नमस्ते, और इस वीडियो में आपका स्वागत है।"
        )

        assertEquals(3300L, segment.durationMs)
        assertEquals("00:01.200 -> 00:04.500", segment.formattedTimeRange())
        assertTrue(segment.translatedHindiText.any { it.code in 0x0900..0x097F }) // Devanagari Unicode
    }

    @Test
    fun audioMixModes_definitionAndLabels() {
        val modes = AudioMixMode.values()
        assertEquals(3, modes.size)
        assertNotNull(AudioMixMode.REPLACE_ORIGINAL)
        assertNotNull(AudioMixMode.DUCK_20)
        assertNotNull(AudioMixMode.DUCK_40)
        assertEquals("Mute Original Audio", AudioMixMode.REPLACE_ORIGINAL.label)
    }

    @Test
    fun timestampFormatter_boundaryValues() {
        val zero = TranscriptSegment.formatTime(0L)
        assertEquals("00:00.000", zero)

        val oneMinute = TranscriptSegment.formatTime(65432L)
        assertEquals("01:05.432", oneMinute)
    }
}
